/*
*/
 
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
 
public class BioMorph extends JFrame implements ActionListener{
	
	private JMenuBar menuBar=new JMenuBar();
	private JMenu file=new JMenu("File");
	private JMenuItem newOrg=new JMenuItem("New Organism");
	private JMenuItem save=new JMenuItem("Save");
	private JMenuItem load=new JMenuItem("Load");
	private JMenu help=new JMenu("Help");
	private JMenu exit=new JMenu("Exit");
	private PrintWriter pw;
	private BufferedReader infile;
	private Evolution e;
			
    public static void main(String[] args){
    	new BioMorph();
    }
    
    BioMorph(){
    	//JFrame Settings    	
    	setTitle("BioMorph");		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setUndecorated(true);
		
		//Menu Bar Settings
		menuBar.add(file);
		file.add(newOrg);
		file.add(save);
		file.add(load);
		menuBar.add(help);
		menuBar.add(exit);
		setJMenuBar(menuBar);
		
		newOrg.addActionListener(this);
		save.addActionListener(this);
		load.addActionListener(this);
		help.addActionListener(this);
		exit.addActionListener(this);
		
		e=new Evolution();
		add(e);
		setVisible(true);
		
		int[] genes={1,1,1,1,1,1,1,1,1,1,1};
		Organism parent=new Organism(genes,1);
		e.setParent(parent);
    }
    
    public void save() throws Exception
    {
    	String orgName=JOptionPane.showInputDialog(this,"Please enter the name of your organism.","Save",JOptionPane.PLAIN_MESSAGE);
    	pw=new PrintWriter(new FileWriter(orgName+".txt"));
    	for(Organism o: e.getTree()){
			int[] genes=o.getGenes();
			for(int i=0; i<genes.length; i++){
				pw.print(genes[i]+" ");
			}
			pw.println();
		}
		pw.close();
    }
    
    public void load() throws Exception
    {
    	String orgName=JOptionPane.showInputDialog(this,"Please enter the name of your saved organism.","Load",JOptionPane.PLAIN_MESSAGE);
    	infile=new BufferedReader(new FileReader(orgName+".txt"));
    	
    	ArrayList<Organism> treeTemp=new ArrayList<Organism>();
    	String line=infile.readLine();
    	int x=0;
    	while(line!=null)
    	{
 			String[] genesSt=line.split(" ");
 			int[] genes=new int[genesSt.length];
 			for(int y=0; y<genesSt.length; y++)
 				genes[y]=Integer.parseInt(genesSt[y]);
 				
 			treeTemp.add(new Organism(genes,x));
    		line=infile.readLine();
    		x++;
    	}
    	infile.close();
    	e.setTree(treeTemp);
    	e.setParent(treeTemp.get(treeTemp.size()-1));
		repaint();
    }
    
    public void actionPerformed(ActionEvent ae){
    	try{
    		if(ae.getSource()==save) save();
    	}
    	catch(Exception e){
    		System.err.println("Caught Exception");
    	}
    	
    	try{
    		if(ae.getSource()==load) load();
    	}
    	catch(Exception e){
    		System.err.println("Caught Exception");
    	}
    }
}
