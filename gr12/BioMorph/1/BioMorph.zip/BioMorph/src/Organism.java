/*
 */
import javax.swing.*;
import java.awt.*;
import java.util.*;
//The actual biomorph class
public class Organism
{
	private int[] genes;//0depth, 1right even vertical, 2right even horizontal, 3right odd vertical, 4right odd horizontal, 5left even vertical, 6left even horizontal, 7left odd vertical, 8left off horizontal, 9colour, 10thickness
	private int generation;
	private Node head;
	private int[] dimensions =  {Integer.MAX_VALUE, Integer.MAX_VALUE,Integer.MIN_VALUE,Integer.MIN_VALUE};//{minX,minY,maxX,maxY} a rectangle bounding the organism - for centering purposes
	
    Organism(int[] forGenes)
    {
    	genes=forGenes;
    	head=new Node(0,0,0, this);
    }
    
    public int[] getDimensions()
    {
    	return dimensions;
    }
    
    public Node getHead()
    {
    	return(head);
    }
    
    public int[] getGenes()
    {
    	return genes;
    }
    
    public ArrayList reproduce()//returns a 3 length ArrayList of children with random mutations
    {
    	ArrayList toReturn = new ArrayList(3);
    	int[] firstRandomMutation = genes;
    	int[] secondRandomMutation = genes;
    	int[] thirdRandomMutation = genes;
    	int firstCounter = 0;
    	int secondCounter = 0;
    	int thirdCounter = 0;
    	Organism firstChild;
    	Organism secondChild;
    	Organism thirdChild;   	
    	
    	//add ability for negative genes
    	//mutate genes for children
    	for(boolean set=false; firstCounter<=genes.length&&set!=true; firstCounter++)
    	{
    		if(firstCounter==genes.length)//did they go through without getting any mutations?
    		{
    			firstCounter=0;
    		}
    		else if((int)(Math.random()*11)+1==1)//11 genes so 1/11 chance they get a mutation on this gene
    		{
    			firstRandomMutation[firstCounter] = firstRandomMutation[firstCounter]+1;
    			set=true;
    		}
    	}
    	for(boolean set=false; secondCounter<=genes.length&&set!=true; secondCounter++)
    	{
    		if(secondCounter==genes.length)//did they go through without getting any mutations?
    		{
    			secondCounter=0;
    		}
    		else if(((int)(Math.random()*11)+1==1)&&(secondCounter!=firstCounter))//11 genes so 1/11 chance they get a mutation on this gene also makes sure the gene isnt the same gene as in firstMutation
    		{
    			secondRandomMutation[secondCounter] = secondRandomMutation[secondCounter]+1;
    			set=true;
    		}
    	}
       	for(boolean set=false; thirdCounter<=genes.length&&set!=true; thirdCounter++)
    	{
    		if(thirdCounter==genes.length)//did they go through without getting any mutations?
    		{
    			thirdCounter=0;
    		}
    		else if(((int)(Math.random()*11)+1==1)&&(thirdCounter!=firstCounter)&&(thirdCounter!=secondCounter))//11 genes so 1/11 chance they get a mutation on this gene also makes sure the gene isnt the same gene as in firstMutation or secondMutation
    		{
    			thirdRandomMutation[thirdCounter] = thirdRandomMutation[thirdCounter]+1;
    			set=true;
    		}
    	}
    	
    	//gives children their genes and creates them
    	firstChild = new Organism(firstRandomMutation);
    	secondChild = new Organism(secondRandomMutation);
    	thirdChild = new Organism(thirdRandomMutation);
    	
    	//adds children to ArrayList toReturn
    	toReturn.add(firstChild);
    	toReturn.add(secondChild);
    	toReturn.add(thirdChild);
    	
    	return(toReturn);
    }
}